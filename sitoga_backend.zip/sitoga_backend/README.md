# SITOGA - Backend Development

## FastAPI - Python Framework

